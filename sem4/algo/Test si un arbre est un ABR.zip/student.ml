(*
    type 'a tree = Empty | Bin of 'a * 'a tree * 'a tree

    Écrire une fonction is_bst : ('a * int) tree -> bool qui teste si un arbre
    est un ABR, en temps O(n) où n est le nombre de noeuds.
    
    Les étiquettes des noeuds de t sont des couples (x, m) où x est la clé et m
    est sa multiplicité.
*)

(* Ne pas supprimer ni modifier la ligne suivante *)
open Type

(* Remplacer la fonction suivante sans changer son nom *)
let rec is_bst t = true



