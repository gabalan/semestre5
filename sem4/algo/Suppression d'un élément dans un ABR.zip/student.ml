(*
    type 'a tree = Empty | Bin of 'a * 'a tree * 'a tree

    Écrire une fonction
    bst_delete : ('a * int) tree -> 'a -> ('a * int) tree
    telle que bst_delete t x supprime une occurrence de x dans t.
*)

(* Ne pas supprimer ni modifier la ligne suivante *)
open Type

(* Remplacer la fonction suivante sans changer son nom *)
let rec bst_delete t x = t



