rm -rf CMakeFiles CMakeCache.txt cmake_install.cmake *~ demo model *.o Makefile
