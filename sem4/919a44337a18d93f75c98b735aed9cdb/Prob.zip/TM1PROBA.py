from random import *
def lancers(n) :
    d={}

    i=randint(1,6)
    for r in range 6 
